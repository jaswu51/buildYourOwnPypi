make sure your build file is latest:
```
python3 -m pip install --upgrade build 
```
```
python3 -m build
```
```
python3 -m twine upload --repository testpypi dist/*
```
```
from buildYourOwnPkgJaswu51 import plotlove
```
reference tutorial: https://www.youtube.com/watch?v=v4bkJef4W94&t=118s


